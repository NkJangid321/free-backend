# 🚀 Shree Bhagwati Silver Backend

A free, serverless backend for the Shree Bhagwati Silver website using Netlify Functions and Supabase.

## ✨ Features

- **🛍️ Product Management** - CRUD operations for silver products
- **📦 Order Management** - Track customer orders
- **👥 Customer Management** - Manage customer database
- **🔧 Admin Panel** - Beautiful dashboard for business operations
- **☁️ Serverless** - No server costs, scales automatically
- **🔒 Secure** - CORS enabled, Supabase authentication

## 🏗️ Architecture

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Netlify Functions (Node.js)
- **Database**: Supabase (PostgreSQL)
- **Deployment**: Netlify (Free tier)

## 🚀 Quick Setup

### 1. Deploy to Netlify

1. **Upload this folder** to Netlify
2. **Set Environment Variables**:
   - `SUPABASE_URL` - Your Supabase project URL
   - `SUPABASE_ANON_KEY` - Your Supabase anonymous key

### 2. Supabase Setup

1. **Create tables** (already done in your project)
2. **Copy credentials** from API settings

### 3. Test the Backend

- **Main page**: `your-site.netlify.app`
- **Admin panel**: `your-site.netlify.app/admin-panel`
- **API endpoints**: `your-site.netlify.app/.netlify/functions/product`

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/.netlify/functions/product` | Get all products |
| POST | `/.netlify/functions/product` | Create product |
| PUT | `/.netlify/functions/product` | Update product |
| DELETE | `/.netlify/functions/product` | Delete product |
| GET | `/.netlify/functions/order` | Get all orders |
| GET | `/.netlify/functions/customer` | Get all customers |

## 🔧 Admin Panel

- **Dashboard**: View business statistics
- **Products**: Add, edit, delete silver products
- **Orders**: Monitor customer orders
- **Customers**: Manage customer database

## 📁 File Structure

```
fresh-backend/
├── netlify/
│   └── functions/
│       ├── product.js    # Product CRUD operations
│       ├── order.js      # Order management
│       └── customer.js   # Customer management
├── admin-panel/
│   ├── index.html        # Admin panel interface
│   ├── styles.css        # Admin panel styling
│   └── script.js         # Admin panel logic
├── index.html            # Main landing page
├── netlify.toml          # Netlify configuration
├── package.json          # Dependencies
└── README.md             # This file
```

## 🎯 Next Steps

1. **Deploy to Netlify** - Upload this entire folder
2. **Set environment variables** in Netlify dashboard
3. **Test the admin panel** at `/admin-panel`
4. **Add your first product** through the admin interface

## 🆘 Troubleshooting

- **404 errors**: Check if functions are deployed in Netlify
- **Database errors**: Verify Supabase credentials
- **CORS issues**: Functions include CORS headers automatically

## 💰 Cost

- **Netlify**: Free tier (100GB bandwidth/month)
- **Supabase**: Free tier (500MB database, 50MB file storage)
- **Total**: $0/month for small to medium business

---

**Ready to deploy! 🚀**
