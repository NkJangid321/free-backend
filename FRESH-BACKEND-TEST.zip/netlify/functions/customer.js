const { createClient } = require('@supabase/supabase-js');
const cors = require('cors')();

exports.handler = async (event, context) => {
  return new Promise((resolve) => {
    cors(event, context, async () => {
      try {
        const supabaseUrl = process.env.SUPABASE_URL;
        const supabaseKey = process.env.SUPABASE_ANON_KEY;
        
        if (!supabaseUrl || !supabaseKey) {
          return resolve({
            statusCode: 500,
            body: JSON.stringify({ error: 'Missing Supabase credentials' })
          });
        }

        const supabase = createClient(supabaseUrl, supabaseKey);

        switch (event.httpMethod) {
          case 'GET':
            const { data: customers, error: getError } = await supabase
              .from('customers')
              .select('*')
              .order('created_at', { ascending: false });
            
            if (getError) throw getError;
            
            return resolve({
              statusCode: 200,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ customers: customers || [] })
            });

          case 'POST':
            const customerData = JSON.parse(event.body);
            const { data: newCustomer, error: postError } = await supabase
              .from('customers')
              .insert([customerData])
              .select();
            
            if (postError) throw postError;
            
            return resolve({
              statusCode: 201,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ customer: newCustomer[0] })
            });

          case 'PUT':
            const { id, ...updateData } = JSON.parse(event.body);
            const { data: updatedCustomer, error: putError } = await supabase
              .from('customers')
              .update(updateData)
              .eq('id', id)
              .select();
            
            if (putError) throw putError;
            
            return resolve({
              statusCode: 200,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ customer: updatedCustomer[0] })
            });

          case 'DELETE':
            const { id: deleteId } = JSON.parse(event.body);
            const { error: deleteError } = await supabase
              .from('customers')
              .delete()
              .eq('id', deleteId);
            
            if (deleteError) throw deleteError;
            
            return resolve({
              statusCode: 200,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ message: 'Customer deleted successfully' })
            });

          default:
            return resolve({
              statusCode: 405,
              body: JSON.stringify({ error: 'Method not allowed' })
            });
        }
      } catch (error) {
        console.error('Error:', error);
        return resolve({
          statusCode: 500,
          body: JSON.stringify({ error: error.message })
        });
      }
    });
  });
};
