const { createClient } = require('@supabase/supabase-js');
const cors = require('cors')();

exports.handler = async (event, context) => {
  return new Promise((resolve) => {
    cors(event, context, async () => {
      try {
        const supabaseUrl = process.env.SUPABASE_URL;
        const supabaseKey = process.env.SUPABASE_ANON_KEY;
        
        if (!supabaseUrl || !supabaseKey) {
          return resolve({
            statusCode: 500,
            body: JSON.stringify({ error: 'Missing Supabase credentials' })
          });
        }

        const supabase = createClient(supabaseUrl, supabaseKey);

        switch (event.httpMethod) {
          case 'GET':
            const { data: orders, error: getError } = await supabase
              .from('orders')
              .select('*')
              .order('created_at', { ascending: false });
            
            if (getError) throw getError;
            
            return resolve({
              statusCode: 200,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ orders: orders || [] })
            });

          case 'POST':
            const orderData = JSON.parse(event.body);
            const { data: newOrder, error: postError } = await supabase
              .from('orders')
              .insert([orderData])
              .select();
            
            if (postError) throw postError;
            
            return resolve({
              statusCode: 201,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ order: newOrder[0] })
            });

          case 'PUT':
            const { id, ...updateData } = JSON.parse(event.body);
            const { data: updatedOrder, error: putError } = await supabase
              .from('orders')
              .update(updateData)
              .eq('id', id)
              .select();
            
            if (putError) throw putError;
            
            return resolve({
              statusCode: 200,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ order: updatedOrder[0] })
            });

          case 'DELETE':
            const { id: deleteId } = JSON.parse(event.body);
            const { error: deleteError } = await supabase
              .from('orders')
              .delete()
              .eq('id', deleteId);
            
            if (deleteError) throw deleteError;
            
            return resolve({
              statusCode: 200,
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ message: 'Order deleted successfully' })
            });

          default:
            return resolve({
              statusCode: 405,
              body: JSON.stringify({ error: 'Method not allowed' })
            });
        }
      } catch (error) {
        console.error('Error:', error);
        return resolve({
          statusCode: 500,
          body: JSON.stringify({ error: error.message })
        });
      }
    });
  });
};
