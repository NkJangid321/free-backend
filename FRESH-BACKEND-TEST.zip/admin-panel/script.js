// Tab switching functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tabs
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            btn.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
            
            // Load data for the selected tab
            loadTabData(targetTab);
        });
    });

    // Load initial dashboard data
    loadTabData('dashboard');
});

// Load data for different tabs
function loadTabData(tab) {
    switch(tab) {
        case 'dashboard':
            loadDashboardStats();
            break;
        case 'products':
            loadProducts();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'customers':
            loadCustomers();
            break;
    }
}

// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const [productsRes, ordersRes, customersRes] = await Promise.all([
            fetch('/.netlify/functions/product'),
            fetch('/.netlify/functions/order'),
            fetch('/.netlify/functions/customer')
        ]);

        const productsData = await productsRes.json();
        const ordersData = await ordersRes.json();
        const customersData = await customersRes.json();

        document.getElementById('totalProducts').textContent = productsData.products?.length || 0;
        document.getElementById('totalOrders').textContent = ordersData.orders?.length || 0;
        document.getElementById('totalCustomers').textContent = customersData.customers?.length || 0;
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        document.getElementById('totalProducts').textContent = 'Error';
        document.getElementById('totalOrders').textContent = 'Error';
        document.getElementById('totalCustomers').textContent = 'Error';
    }
}

// Load products
async function loadProducts() {
    try {
        const response = await fetch('/.netlify/functions/product');
        if (!response.ok) throw new Error('Failed to fetch products');
        
        const data = await response.json();
        const products = data.products || [];
        
        displayProducts(products);
    } catch (error) {
        console.error('Error loading products:', error);
        document.getElementById('productsTableBody').innerHTML = 
            '<tr><td colspan="6">Error loading products</td></tr>';
    }
}

// Display products in table
function displayProducts(products) {
    const tbody = document.getElementById('productsTableBody');
    
    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No products found</td></tr>';
        return;
    }

    tbody.innerHTML = products.map(product => `
        <tr>
            <td>${product.id}</td>
            <td>${product.name || 'N/A'}</td>
            <td>${product.description || 'N/A'}</td>
            <td>₹${product.price || 'N/A'}</td>
            <td>${product.category || 'N/A'}</td>
            <td>
                <button class="action-btn edit-btn" onclick="editProduct(${product.id})">Edit</button>
                <button class="action-btn delete-btn" onclick="deleteProduct(${product.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

// Load orders
async function loadOrders() {
    try {
        const response = await fetch('/.netlify/functions/order');
        if (!response.ok) throw new Error('Failed to fetch orders');
        
        const data = await response.json();
        const orders = data.orders || [];
        
        displayOrders(orders);
    } catch (error) {
        console.error('Error loading orders:', error);
        document.getElementById('ordersTableBody').innerHTML = 
            '<tr><td colspan="6">Error loading orders</td></tr>';
    }
}

// Display orders in table
function displayOrders(orders) {
    const tbody = document.getElementById('ordersTableBody');
    
    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No orders found</td></tr>';
        return;
    }

    tbody.innerHTML = orders.map(order => `
        <tr>
            <td>${order.id}</td>
            <td>${order.customer_name || 'N/A'}</td>
            <td>${order.products || 'N/A'}</td>
            <td>₹${order.total || 'N/A'}</td>
            <td>${order.status || 'N/A'}</td>
            <td>${new Date(order.created_at).toLocaleDateString()}</td>
        </tr>
    `).join('');
}

// Load customers
async function loadCustomers() {
    try {
        const response = await fetch('/.netlify/functions/customer');
        if (!response.ok) throw new Error('Failed to fetch customers');
        
        const data = await response.json();
        const customers = data.customers || [];
        
        displayCustomers(customers);
    } catch (error) {
        console.error('Error loading customers:', error);
        document.getElementById('customersTableBody').innerHTML = 
            '<tr><td colspan="6">Error loading customers</td></tr>';
    }
}

// Display customers in table
function displayCustomers(customers) {
    const tbody = document.getElementById('customersTableBody');
    
    if (customers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No customers found</td></tr>';
        return;
    }

    tbody.innerHTML = customers.map(customer => `
        <tr>
            <td>${customer.id}</td>
            <td>${customer.name || 'N/A'}</td>
            <td>${customer.email || 'N/A'}</td>
            <td>${customer.phone || 'N/A'}</td>
            <td>${customer.address || 'N/A'}</td>
            <td>${new Date(customer.created_at).toLocaleDateString()}</td>
        </tr>
    `).join('');
}

// Product form functions
function showAddProductForm() {
    document.getElementById('addProductForm').style.display = 'block';
}

function hideAddProductForm() {
    document.getElementById('addProductForm').style.display = 'none';
    document.getElementById('productForm').reset();
}

// Handle product form submission
document.getElementById('productForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const productData = {
        name: formData.get('name'),
        description: formData.get('description'),
        price: parseFloat(formData.get('price')),
        category: formData.get('category'),
        image_url: formData.get('image_url') || null
    };

    try {
        const response = await fetch('/.netlify/functions/product', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productData)
        });

        if (!response.ok) throw new Error('Failed to create product');

        alert('Product created successfully!');
        hideAddProductForm();
        loadProducts();
        loadDashboardStats();
    } catch (error) {
        console.error('Error creating product:', error);
        alert('Error creating product: ' + error.message);
    }
});

// Edit product
function editProduct(id) {
    // This would open an edit form - simplified for now
    alert('Edit functionality would open here for product ID: ' + id);
}

// Delete product
async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
        const response = await fetch('/.netlify/functions/product', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id })
        });

        if (!response.ok) throw new Error('Failed to delete product');

        alert('Product deleted successfully!');
        loadProducts();
        loadDashboardStats();
    } catch (error) {
        console.error('Error deleting product:', error);
        alert('Error deleting product: ' + error.message);
    }
}
